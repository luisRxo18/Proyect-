package poo.videojuego.prueba;

public abstract interface Pruebas
{
  public abstract void setArgumentos(String[] paramArrayOfString);
  
  public abstract void init();
}

package poo.videojuego.prueba;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import poo.videojuego.Ataque;
import poo.videojuego.Item;
import poo.videojuego.Personaje;

public class FabricaPrueba implements poo.videojuego.FabricaDeObjetos
{
  public FabricaPrueba() {}
  
  public Personaje construyePersonajeDesdeCadena(String cadena)
  {
    new Personaje()
    {
      public void usa(Item item) {}
      



      public void recibe(Ataque ataque) {}
      



      public Ataque lanza(String nombreAtaque)
      {
        return null;
      }
      


      public void guardaEnArchivo(String archivo) {}
      


      public void guarda(Ataque ataque) {}
      


      public String getNombre()
      {
        return null;
      }
      
      public int getExperiencia()
      {
        return 0;
      }
      
      public int getEnergia()
      {
        return 0;
      }
      
      public Collection<Ataque> getAtaques()
      {
        return null;
      }
    };
  }
  

  public Collection<Personaje> cargaPesonajesDesdeArchivo(String archivo)
  {
    return Arrays.asList(new Personaje[] { new PersonajePrueba("pikachu", Collections.emptyList()), new PersonajePrueba("geralt", Collections.emptyList()) });
  }
  
  public Collection<Item> construyeUnItemDeCadaTipo()
  {
    return Arrays.asList(new Item[] { new ItemPrueba("pocima") });
  }
  
  public Item construyeItemPorNombre(String nombre)
  {
    return null;
  }
  
  public Collection<Ataque> construyeUnAtaqueDeCadaClase()
  {
    Arrays.asList(new Ataque[] { new Ataque()
    {
      public String getNombre()
      {
        return null;
      }
      
      public int getExperienciaQueAporta()
      {
        return 0;
      }
      
      public int getExperienciaNecesaria()
      {
        return 0;
      }
      
      public int getDanoQueCausa()
      {
        return 0;
      }
    } });
  }
  
  public Ataque construyeAtaquePorNombre(String nombre)
  {
    return null;
  }
}

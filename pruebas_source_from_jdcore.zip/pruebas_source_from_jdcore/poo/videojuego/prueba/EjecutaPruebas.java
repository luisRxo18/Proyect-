package poo.videojuego.prueba;

import java.io.PrintStream;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;

public class EjecutaPruebas
{
  private Class<? extends Pruebas> clazzPrueba;
  private String[] argumentos;
  
  public EjecutaPruebas(Class<? extends Pruebas> clazzPrueba, String[] args)
  {
    verificaAssertionsActivadas();
    this.clazzPrueba = clazzPrueba;
    argumentos = args;
  }
  
  public void ejecuta() {
    Collection<Method> pruebas = getPruebas();
    
    for (Method method : pruebas) {
      System.out.print(method.getName() + ":");
      try {
        method.invoke(newPrueba(), new Object[0]);
      } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
        System.out.print("[ERROR]");
        if ((e.getCause() != null) && ((e.getCause() instanceof AssertionError))) {
          System.out.println(" - " + e.getCause().getMessage());
          continue; }
        System.out.println();
        e.printStackTrace(System.out);
        

        continue;
      }
      System.out.println("[OK]");
    }
  }
  
  private Pruebas newPrueba()
  {
    try {
      newInstance = (Pruebas)clazzPrueba.newInstance();
    } catch (InstantiationException|IllegalAccessException e) { Pruebas newInstance;
      throw new RuntimeException(e); }
    Pruebas newInstance;
    newInstance.setArgumentos(argumentos);
    newInstance.init();
    
    return newInstance;
  }
  
  private Collection<Method> getPruebas() {
    Collection<Method> res = new java.util.ArrayList();
    for (Method method : clazzPrueba.getDeclaredMethods()) {
      if (method.getName().startsWith("prueba"))
      {

        if (Modifier.isPublic(method.getModifiers()))
        {

          if (method.getParameterTypes().length == 0)
          {

            res.add(method); } } }
    }
    return res;
  }
  
  private void verificaAssertionsActivadas() {
    boolean assertionActivas = false;
    try
    {
      if (!$assertionsDisabled) throw new AssertionError();
    }
    catch (AssertionError e) {
      assertionActivas = true;
      
      if (!assertionActivas) {
        throw new IllegalArgumentException(
          "No se habilitaron los assert, ejecuta de nuevo incluyendo la bandera -ea");
      }
    }
  }
}

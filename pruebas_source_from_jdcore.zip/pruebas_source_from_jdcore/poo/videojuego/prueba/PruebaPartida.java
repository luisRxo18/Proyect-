package poo.videojuego.prueba;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import poo.videojuego.Ataque;
import poo.videojuego.Item;
import poo.videojuego.Personaje;
import poo.videojuego.ui.Accion;
import poo.videojuego.ui.Partida;

public class PruebaPartida implements Pruebas
{
  private Map<String, Object> contexto;
  private Partida SUT;
  
  public PruebaPartida() {}
  
  public static void main(String[] args)
  {
    EjecutaPruebas ejecutaPruebas = new EjecutaPruebas(PruebaPartida.class, args);
    ejecutaPruebas.ejecuta();
  }
  
  public void setArgumentos(String[] argumentos)
  {
    assert (argumentos.length == 1) : "numero de parametros de ejecucion incorrecto";
    Map<String, Object> context = new java.util.HashMap();
    context.put("nombreClasePartida", argumentos[0]);
    contexto = context;
  }
  
  public void init()
  {
    SUT = newPartida(contexto.get("nombreClasePartida").toString());
    assert (SUT != null) : "No se tiene la clase Partida";
    
    SUT.configura(new FabricaPrueba(), "", new UIPrueba(), 1, 1);
  }
  
  public void pruebaGetAtaquesDisponibles()
  {
    Collection<Ataque> ataquesDisponibles = SUT.getAtaquesDisponibles();
    assert (ataquesDisponibles != null) : "ataquesDisponibles no debe devolver null";
    assert (!ataquesDisponibles.isEmpty()) : "ataquesDisponibles no debe ser vacio";
  }
  
  public void pruebaGetPersonajes() {
    Collection<Personaje> personajes = SUT.getPersonajes();
    assert (personajes != null) : "personajes no debe devolver null";
    assert (!personajes.isEmpty()) : "personajes no debe ser vacio";
  }
  
  public void pruebaGetItemsDisponibles() {
    Collection<Item> itemsDisponibles = SUT.getItemsDisponibles();
    assert (itemsDisponibles != null) : "itemsDisponibles no debe devolver null";
    assert (!itemsDisponibles.isEmpty()) : "itemsDisponibles no debe ser vacio";
  }
  
  public void pruebaGetPersonajeEnTurno() {
    Personaje personajeEnTurno = SUT.getPersonajeEnTurno();
    assert (personajeEnTurno != null) : "no debe devolver null";
  }
  
  public void pruebaEjecutaAccionEjecutaLaAccion() {
    final Vector<Long> ejecuciones = new Vector();
    Accion laAccion = new Accion()
    {
      public void ejecuta() {
        ejecuciones.add(Long.valueOf(System.currentTimeMillis()));
      }
    };
    SUT.inicia();
    
    SUT.ejecutaAccion(laAccion);
    SUT.ejecutaAccion(laAccion);
    SUT.ejecutaAccion(laAccion);
    
    assert (ejecuciones.size() == 3) : "No se estan ejecutando las acciones";
  }
  
  public void pruebaEjecutaAccionConCadaEjecucionCambiaDeTurno() {
    SUT.inicia();
    
    Personaje personajeAnterior = SUT.getPersonajeEnTurno();
    
    SUT.ejecutaAccion(new Accion()
    {

      public void ejecuta() {}

    });
    Personaje personajeEnTurno = SUT.getPersonajeEnTurno();
    
    assert (personajeAnterior != personajeEnTurno) : "Debe cambiar de turno con cada accion";
  }
  
  public void pruebaEjecutaAccionAvanzaDeRonda() {
    SUT.configura(new FabricaPrueba(), "", new UIPrueba(), 3, 1);
    SUT.inicia();
    
    int rondaAnterior = SUT.getRondaActual();
    
    int turnosPorRonda = SUT.getPersonajes().size();
    for (int i = 0; i < turnosPorRonda; i++) {
      SUT.ejecutaAccion(new Accion()
      {
        public void ejecuta() {}
      });
    }
    

    int rondaActual = SUT.getRondaActual();
    
    assert (rondaActual == rondaAnterior + 1) : "Debe avanzar de ronda al ejecutar todos los turnos";
  }
  
  public void pruebaFinalizaAlTerminarRondas() {
    int totalRondas = 2;
    SUT.configura(new FabricaPrueba(), "", new UIPrueba(), totalRondas, 1);
    SUT.inicia();
    
    int turnosTotales = SUT.getPersonajes().size() * totalRondas;
    for (int i = 0; i < turnosTotales; i++) {
      SUT.ejecutaAccion(new Accion()
      {
        public void ejecuta() {}
      });
    }
    

    int rondaActual = SUT.getRondaActual();
    
    assert (rondaActual == -1) : "Al terminar las rondas, la getRondaActual() dede devolver -1";
  }
  
  public void pruebaItemsIniciales() {
    int itemsIniciales = 3;
    SUT.configura(new FabricaPrueba(), "", new UIPrueba(), 1, itemsIniciales);
    SUT.inicia();
    
    assert (SUT.getItemsDisponibles()
      .size() == itemsIniciales) : 
      ("Debe iniciar con el numero de items configurados, se esperaba: " + itemsIniciales + ", se tienen: " + SUT.getItemsDisponibles().size());
  }
  
  public void pruebaItemUsado() {
    SUT.configura(new FabricaPrueba(), "", new UIPrueba(), 1, 3);
    SUT.inicia();
    
    SUT.itemUsado((Item)SUT.getItemsDisponibles().iterator().next());
    SUT.itemUsado((Item)SUT.getItemsDisponibles().iterator().next());
    
    assert (SUT.getItemsDisponibles().size() == 1) : 
      ("Se esperaba 1 item restante, se tiene " + SUT.getItemsDisponibles().size());
  }
  
  public void pruebaLlamadasAUIDentroDeEjecutaAccion()
  {
    final List<String> llamadasAUI = new java.util.ArrayList();
    
    poo.videojuego.ui.PartidaUI ui = new UIPrueba()
    {
      public void limpiaMensajes() {
        llamadasAUI.add("limpiaMensajes");
      }
      
      public void iniciaRonda()
      {
        llamadasAUI.add("iniciaRonda");
      }
      
      public void terminaRonda()
      {
        llamadasAUI.add("terminaRonda");
      }
      
      public void iniciaTurno()
      {
        llamadasAUI.add("iniciaTurno");
      }
      
      public void terminaTurno()
      {
        llamadasAUI.add("terminaTurno");
      }
      
      public void iniciaPartida()
      {
        llamadasAUI.add("iniciaPartida");
      }
      
      public void terminaPartida()
      {
        llamadasAUI.add("terminaPartida");
      }
      
    };
    SUT.configura(new FabricaPrueba()
    {
      public Collection<Personaje> cargaPesonajesDesdeArchivo(String archivo) {
        return Arrays.asList(new Personaje[] { new PersonajePrueba("ryu", Collections.emptyList()) });
      }
    }, "", ui, 1, 1);
    
    SUT.inicia();
    
    int turnosPorRonda = SUT.getPersonajes().size();
    for (int i = 0; i < turnosPorRonda; i++) {
      SUT.ejecutaAccion(new Accion()
      {
        public void ejecuta() {
          llamadasAUI.add("ejecuta");
        }
      });
    }
    

    List<String> llamadasEsperadas = Arrays.asList(new String[] { "iniciaPartida", "iniciaRonda", "limpiaMensajes", "iniciaTurno", "ejecuta", "terminaTurno", "terminaRonda", "terminaPartida" });
    
    assert (llamadasEsperadas.equals(llamadasAUI)) : 
      ("No se hicieron las llamdas a la UI, se esperaba: " + llamadasEsperadas + " y se tiene: " + llamadasAUI);
  }
  
  public void pruebaGuardaArchivoAlTerminarPartida()
  {
    final Set<String> llamadasAGuardar = new HashSet();
    String archivo = "archivo";
    





    final List<Personaje> personajes = Arrays.asList(new Personaje[] { new PersonajePrueba("mai", Collections.emptyList())new PersonajePrueba
    {
      public void guardaEnArchivo(String archivo) {
        llamadasAGuardar.add(getNombre() + "-" + archivo);
      }
    }, new PersonajePrueba("kasumi", Collections.emptyList())
    {
      public void guardaEnArchivo(String archivo) {
        llamadasAGuardar.add(getNombre() + "->" + archivo);
      }
      
    } });
    int totalRondas = 2;
    SUT.configura(new FabricaPrueba()
    {
      public Collection<Personaje> cargaPesonajesDesdeArchivo(String archivo) {
        return personajes;
      }
    }, archivo, new UIPrueba(), totalRondas, 1);
    
    SUT.inicia();
    
    int totalTurnos = personajes.size() * totalRondas;
    for (int i = 0; i < totalTurnos; i++) {
      SUT.ejecutaAccion(new Accion()
      {
        public void ejecuta() {}
      });
    }
    


    Set<String> llamadasEsperadas = new HashSet(Arrays.asList(new String[] { "mai-" + archivo, "kasumi->" + archivo }));
    
    assert (llamadasEsperadas
      .equals(llamadasAGuardar)) : 
      ("Al terminar la partida debe mandar llamar a guardar, se esperaban las llamdas:" + llamadasEsperadas + " se tienen:" + llamadasAGuardar);
  }
  

  private Partida newPartida(String className)
  {
    try
    {
      clazz = Class.forName(className);
    } catch (ClassNotFoundException e) { Class<Partida> clazz;
      throw new RuntimeException(e);
    }
    try { Class<Partida> clazz;
      return (Partida)clazz.newInstance();
    } catch (InstantiationException|IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }
}

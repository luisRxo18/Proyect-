package poo.videojuego.prueba;

import poo.videojuego.Item;

public class ItemPrueba implements Item
{
  private String nombre;
  
  public ItemPrueba(String nombre) {
    this.nombre = nombre;
  }
  
  public String getNombre()
  {
    return nombre;
  }
  
  public int getEnergiaQueAporta()
  {
    return 0;
  }
  
  public int getExperienciaQueAporta()
  {
    return 0;
  }
  
  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    result = 31 * result + (nombre == null ? 0 : nombre.hashCode());
    return result;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ItemPrueba other = (ItemPrueba)obj;
    if (nombre == null) {
      if (nombre != null)
        return false;
    } else if (!nombre.equals(nombre))
      return false;
    return true;
  }
}

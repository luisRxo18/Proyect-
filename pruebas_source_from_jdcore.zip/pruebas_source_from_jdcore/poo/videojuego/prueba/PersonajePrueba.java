package poo.videojuego.prueba;

import java.util.Collection;
import poo.videojuego.Ataque;
import poo.videojuego.Item;
import poo.videojuego.Personaje;

public class PersonajePrueba
  implements Personaje
{
  private Collection<Ataque> ataques;
  private String nombre;
  
  public PersonajePrueba(String nombre, Collection<Ataque> ataques)
  {
    this.nombre = nombre;
    this.ataques = ataques;
  }
  
  public Ataque lanza(String nombreAtaque)
  {
    return null;
  }
  



  public void recibe(Ataque ataque) {}
  


  public void usa(Item item) {}
  


  public void guarda(Ataque ataque) {}
  


  public Collection<Ataque> getAtaques()
  {
    return ataques;
  }
  
  public int getExperiencia()
  {
    return 0;
  }
  
  public int getEnergia()
  {
    return 0;
  }
  
  public String getNombre()
  {
    return nombre;
  }
  
  public void guardaEnArchivo(String archivo) {}
}

package poo.videojuego.prueba;

import poo.videojuego.ui.PartidaUI;

public class UIPrueba
  implements PartidaUI
{
  public UIPrueba() {}
  
  public void muestraEstadoPartida() {}
  
  public void configurando() {}
  
  public void iniciaPartida() {}
  
  public void iniciaRonda() {}
  
  public void terminaRonda() {}
  
  public void iniciaTurno() {}
  
  public void terminaTurno() {}
  
  public void terminaPartida() {}
  
  public void despliegaMensaje(String mensaje) {}
  
  public void despliegaError(String error) {}
  
  public void limpiaMensajes() {}
}
